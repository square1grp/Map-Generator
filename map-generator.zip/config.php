<?php
define( 'GOOGLE_API_KEY', 'AIzaSyCn_istTAe6gRiAmnebvSj8KsLea5YP2BU' );